![](./images/Task_2_1_2.png)


![](./images/Task_2_3.png)
