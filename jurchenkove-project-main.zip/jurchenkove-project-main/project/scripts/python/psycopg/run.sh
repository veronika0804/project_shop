#!/usr/bin/bash

python3 `dirname "$0"`/main.py

