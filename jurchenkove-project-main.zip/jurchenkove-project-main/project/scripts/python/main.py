import math

print(f"10!={math.factorial(10)}")

