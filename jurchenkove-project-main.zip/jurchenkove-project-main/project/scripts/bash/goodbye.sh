#!/usr/bin/bash
echo 'Goodbye, World!'

